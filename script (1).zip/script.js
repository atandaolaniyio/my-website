// Perceptron Class
class Perceptron {
    constructor(inputSize, learningRate = 0.01) {
        this.weights = new Array(inputSize).fill(0).map(() => Math.random() * 2 - 1);
        this.bias = Math.random() * 2 - 1;
        this.learningRate = learningRate;
    }

    activate(sum) {
        return sum > 0 ? 1 : -1;
    }

    predict(inputs) {
        let sum = this.bias;
        for (let i = 0; i < this.weights.length; i++) {
            sum += inputs[i] * this.weights[i];
        }
        return this.activate(sum);
    }

    train(inputs, target) {
        const prediction = this.predict(inputs);
        const error = target - prediction;
        
        for (let i = 0; i < this.weights.length; i++) {
            this.weights[i] += error * inputs[i] * this.learningRate;
        }
        this.bias += error * this.learningRate;
        
        return Math.abs(error) > 0;
    }
}

// Application State
const gridSize = 10;
const totalCells = gridSize * gridSize;
let grid = new Array(totalCells).fill(0);
let trainingData = [];
let perceptron = new Perceptron(totalCells, 0.01);
let lCount = 0;
let tCount = 0;

// DOM Elements
const gridContainer = document.getElementById('grid');
const statusDiv = document.getElementById('status');
const lCountSpan = document.getElementById('lCount');
const tCountSpan = document.getElementById('tCount');
const totalCountSpan = document.getElementById('totalCount');

// Create the grid UI
function createGrid() {
    gridContainer.innerHTML = '';
    for (let i = 0; i < totalCells; i++) {
        const cell = document.createElement('div');
        cell.className = 'cell';
        cell.dataset.index = i;
        
        cell.addEventListener('click', () => toggleCell(i));
        cell.addEventListener('mouseenter', (e) => {
            if (e.buttons === 1) {
                toggleCell(i);
            }
        });
        
        gridContainer.appendChild(cell);
    }
}

// Toggle a cell on/off
function toggleCell(index) {
    grid[index] = grid[index] ? 0 : 1;
    updateGridDisplay();
}

// Update the visual representation of the grid
function updateGridDisplay() {
    const cells = document.querySelectorAll('.cell');
    cells.forEach((cell, index) => {
        if (grid[index] === 1) {
            cell.classList.add('active');
        } else {
            cell.classList.remove('active');
        }
    });
}

// Clear the grid
function clearGrid() {
    grid = new Array(totalCells).fill(0);
    updateGridDisplay();
    statusDiv.textContent = '🗑️ Grid cleared. Draw a new pattern.';
}

// Save current pattern as L
function saveL() {
    const pattern = [...grid];
    if (pattern.some(cell => cell === 1)) {
        trainingData.push({
            input: pattern,
            label: 1
        });
        lCount++;
        updateCounts();
        clearGrid();
        statusDiv.textContent = `✅ Saved as L. Total L: ${lCount}, T: ${tCount}`;
    } else {
        statusDiv.textContent = '❌ Cannot save empty pattern. Draw something first.';
    }
}

// Save current pattern as T
function saveT() {
    const pattern = [...grid];
    if (pattern.some(cell => cell === 1)) {
        trainingData.push({
            input: pattern,
            label: -1
        });
        tCount++;
        updateCounts();
        clearGrid();
        statusDiv.textContent = `✅ Saved as T. Total L: ${lCount}, T: ${tCount}`;
    } else {
        statusDiv.textContent = '❌ Cannot save empty pattern. Draw something first.';
    }
}

// Update count displays
function updateCounts() {
    lCountSpan.textContent = lCount;
    tCountSpan.textContent = tCount;
    totalCountSpan.textContent = lCount + tCount;
}

// Train the perceptron
function train() {
    if (trainingData.length < 100) {
        statusDiv.textContent = `⚠️ Need 100 samples (50 L, 50 T). Currently have ${lCount} L and ${tCount} T.`;
        return;
    }
    
    let epochs = 500;
    let errors;
    let epochErrors = [];
    
    statusDiv.textContent = '⚡ Training on 100 samples... Please wait.';
    
    for (let epoch = 0; epoch < epochs; epoch++) {
        errors = 0;
        const shuffled = [...trainingData].sort(() => Math.random() - 0.5);
        
        for (const data of shuffled) {
            const hadError = perceptron.train(data.input, data.label);
            if (hadError) errors++;
        }
        
        epochErrors.push(errors);
        
        if (errors === 0) {
            statusDiv.textContent = `✅ Training complete! Converged after ${epoch + 1} epochs.`;
            return;
        }
    }
    
    const avgErrors = (epochErrors.reduce((a, b) => a + b, 0) / epochErrors.length).toFixed(2);
    statusDiv.textContent = `📊 Training finished. Average errors per epoch: ${avgErrors}`;
}

// Test the current pattern
function test() {
    if (trainingData.length < 100) {
        statusDiv.textContent = `⚠️ Need 100 samples for reliable testing. Currently have ${lCount + tCount} samples.`;
        return;
    }
    
    const pattern = [...grid];
    if (!pattern.some(cell => cell === 1)) {
        statusDiv.textContent = '✏️ Draw a pattern to test first.';
        return;
    }
    
    const prediction = perceptron.predict(pattern);
    const result = prediction === 1 ? 'L' : 'T';
    const confidence = calculateConfidence(pattern, prediction);
    
    statusDiv.textContent = `🔍 Testing - It is a ${result} (confidence: ${confidence.toFixed(2)}%)`;
}

// Calculate confidence based on distance from decision boundary
function calculateConfidence(inputs, prediction) {
    let sum = perceptron.bias;
    for (let i = 0; i < perceptron.weights.length; i++) {
        sum += inputs[i] * perceptron.weights[i];
    }
    const confidence = Math.min(100, Math.max(0, Math.abs(sum) * 50));
    return confidence;
}

// Generate 50 L samples with variations
function generateLSamples() {
    const samples = [];
    
    for (let i = 0; i < 50; i++) {
        const pattern = new Array(totalCells).fill(0);
        
        const thickness = Math.floor(Math.random() * 2) + 1;
        const verticalStart = Math.floor(Math.random() * 3);
        const verticalEnd = gridSize - 1 - Math.floor(Math.random() * 2);
        const horizontalEnd = gridSize - 1 - Math.floor(Math.random() * 2);
        const verticalPos = Math.floor(Math.random() * 3);
        
        // Draw vertical line
        for (let row = verticalStart; row <= verticalEnd; row++) {
            for (let t = 0; t < thickness; t++) {
                if (verticalPos + t < gridSize) {
                    pattern[row * gridSize + verticalPos + t] = 1;
                }
            }
        }
        
        // Draw horizontal line
        for (let col = 0; col <= horizontalEnd; col++) {
            for (let t = 0; t < thickness; t++) {
                if (verticalEnd - t >= 0) {
                    pattern[(verticalEnd - t) * gridSize + col] = 1;
                }
            }
        }
        
        samples.push({ input: pattern, label: 1 });
    }
    
    return samples;
}

// Generate 50 T samples with variations
function generateTSamples() {
    const samples = [];
    
    for (let i = 0; i < 50; i++) {
        const pattern = new Array(totalCells).fill(0);
        
        const thickness = Math.floor(Math.random() * 2) + 1;
        const topRow = Math.floor(Math.random() * 2);
        const bottomRow = gridSize - 1 - Math.floor(Math.random() * 3);
        const horizontalStart = Math.floor(Math.random() * 3);
        const horizontalEnd = gridSize - 1 - Math.floor(Math.random() * 2);
        const verticalPos = Math.floor(Math.random() * 4) + 3;
        
        // Draw horizontal top bar
        for (let col = horizontalStart; col <= horizontalEnd; col++) {
            for (let t = 0; t < thickness; t++) {
                if (topRow + t < gridSize) {
                    pattern[(topRow + t) * gridSize + col] = 1;
                }
            }
        }
        
        // Draw vertical stem
        for (let row = topRow + thickness; row <= bottomRow; row++) {
            for (let t = 0; t < thickness; t++) {
                if (verticalPos + t < gridSize) {
                    pattern[row * gridSize + verticalPos + t] = 1;
                }
            }
        }
        
        samples.push({ input: pattern, label: -1 });
    }
    
    return samples;
}

// Add noise to patterns
function addNoiseToPattern(pattern, noiseLevel = 0.05) {
    const noisyPattern = [...pattern];
    for (let i = 0; i < noisyPattern.length; i++) {
        if (Math.random() < noiseLevel) {
            noisyPattern[i] = noisyPattern[i] ? 0 : 1;
        }
    }
    return noisyPattern;
}

// Initialize with 100 samples
function initialize100Samples() {
    const lSamples = generateLSamples();
    const tSamples = generateTSamples();
    
    trainingData = [];
    lCount = 0;
    tCount = 0;
    
    // Add 40 original L samples
    for (let i = 0; i < 40; i++) {
        trainingData.push(lSamples[i]);
        lCount++;
    }
    
    // Add 10 L samples with noise
    for (let i = 0; i < 10; i++) {
        const sample = lSamples[i % 40];
        const noisyInput = addNoiseToPattern(sample.input, 0.03);
        trainingData.push({ input: noisyInput, label: 1 });
        lCount++;
    }
    
    // Add 40 original T samples
    for (let i = 0; i < 40; i++) {
        trainingData.push(tSamples[i]);
        tCount++;
    }
    
    // Add 10 T samples with noise
    for (let i = 0; i < 10; i++) {
        const sample = tSamples[i % 40];
        const noisyInput = addNoiseToPattern(sample.input, 0.03);
        trainingData.push({ input: noisyInput, label: -1 });
        tCount++;
    }
    
    // Shuffle the data
    trainingData = trainingData.sort(() => Math.random() - 0.5);
    
    updateCounts();
    statusDiv.textContent = '✅ Loaded 100 samples (50 L, 50 T) with variations. Click Train to start learning!';
}

// Initialize the app
function init() {
    createGrid();
    
    document.getElementById('clearBtn').addEventListener('click', clearGrid);
    document.getElementById('saveLBtn').addEventListener('click', saveL);
    document.getElementById('saveTBtn').addEventListener('click', saveT);
    document.getElementById('trainBtn').addEventListener('click', train);
    document.getElementById('testBtn').addEventListener('click', test);
    
    initialize100Samples();
}

// Start the app when page loads
window.addEventListener('load', init);