
import torch
import torch.nn as nn
import numpy as np
import joblib

class WineQualityDNN(nn.Module):
    def __init__(self, input_size=11, hidden_sizes=[256, 128, 64, 32]):
        super(WineQualityDNN, self).__init__()
        self.input_layer = nn.Linear(input_size, hidden_sizes[0])
        self.bn1 = nn.BatchNorm1d(hidden_sizes[0])
        self.hidden1 = nn.Linear(hidden_sizes[0], hidden_sizes[1])
        self.bn2 = nn.BatchNorm1d(hidden_sizes[1])
        self.hidden2 = nn.Linear(hidden_sizes[1], hidden_sizes[2])
        self.bn3 = nn.BatchNorm1d(hidden_sizes[2])
        self.hidden3 = nn.Linear(hidden_sizes[2], hidden_sizes[3])
        self.bn4 = nn.BatchNorm1d(hidden_sizes[3])
        self.output_layer = nn.Linear(hidden_sizes[3], 1)
        self.dropout = nn.Dropout(0.2)
        
    def forward(self, x):
        x = torch.relu(self.bn1(self.input_layer(x)))
        x = self.dropout(x)
        x = torch.relu(self.bn2(self.hidden1(x)))
        x = self.dropout(x)
        x = torch.relu(self.bn3(self.hidden2(x)))
        x = self.dropout(x)
        x = torch.relu(self.bn4(self.hidden3(x)))
        x = self.dropout(x)
        x = self.output_layer(x)
        return x

# Load model
model = WineQualityDNN()
model.load_state_dict(torch.load('wine_quality_model.pth', map_location=torch.device('cpu')))
model.eval()

# Load scaler
scaler = joblib.load('scaler.pkl')

def predict(fixed_acidity, volatile_acidity, citric_acid, residual_sugar,
            chlorides, free_sulfur_dioxide, total_sulfur_dioxide, density,
            ph, sulphates, alcohol):
    features = np.array([[fixed_acidity, volatile_acidity, citric_acid, residual_sugar,
                          chlorides, free_sulfur_dioxide, total_sulfur_dioxide, density,
                          ph, sulphates, alcohol]])
    features_scaled = scaler.transform(features)
    features_tensor = torch.FloatTensor(features_scaled)
    with torch.no_grad():
        prediction = model(features_tensor).numpy()
    return prediction[0][0]

# Example usage
if __name__ == "__main__":
    quality = predict(7.4, 0.7, 0.0, 1.9, 0.076, 11, 34, 0.9978, 3.51, 0.56, 9.4)
    print(f"Predicted wine quality: {quality:.2f}")
